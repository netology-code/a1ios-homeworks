//
//  FirstCourseSecondTaskChecker.h
//  FirstCourseSecondTaskChecker
//
//  Copyright © 2017 E-Legion. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for FirstCourseSecondTaskChecker.
FOUNDATION_EXPORT double FirstCourseSecondTaskCheckerVersionNumber;

//! Project version string for FirstCourseSecondTaskChecker.
FOUNDATION_EXPORT const unsigned char FirstCourseSecondTaskCheckerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FirstCourseSecondTaskChecker/PublicHeader.h>


