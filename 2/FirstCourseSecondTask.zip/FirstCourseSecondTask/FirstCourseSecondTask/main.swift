//
//  main.swift
//  FirstCourseSecondTask
//
//  Copyright © 2017 E-Legion. All rights reserved.
//

import Foundation
import FirstCourseSecondTaskChecker


let checker = Checker()


checker.checkFirstFunction(function: <#T##([Int]) -> (Int, Int)#>)


checker.checkSecondFunction(function: <#T##([Checker.Circle]) -> [Checker.Circle]#>)


checker.checkThirdFunction(function: <#T##([Checker.EmployeeData]) -> [Checker.Employee]#>)


checker.checkFourthFunction(function: <#T##([String]) -> [String : [String]]#>)
