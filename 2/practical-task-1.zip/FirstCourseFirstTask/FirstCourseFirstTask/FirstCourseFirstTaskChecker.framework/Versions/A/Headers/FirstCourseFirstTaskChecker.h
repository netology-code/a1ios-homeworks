//
//  FirstCourseFirstTaskChecker.h
//  FirstCourseFirstTaskChecker
//
//  Copyright © 2017 E-Legion. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for FirstCourseFirstTaskChecker.
FOUNDATION_EXPORT double FirstCourseFirstTaskCheckerVersionNumber;

//! Project version string for FirstCourseFirstTaskChecker.
FOUNDATION_EXPORT const unsigned char FirstCourseFirstTaskCheckerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FirstCourseFirstTaskChecker/PublicHeader.h>


