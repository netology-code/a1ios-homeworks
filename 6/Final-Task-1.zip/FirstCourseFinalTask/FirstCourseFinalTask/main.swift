//
//  main.swift
//  FirstCourseFinalTask
//
//  Copyright © 2017 E-Legion. All rights reserved.
//

import Foundation
import FirstCourseFinalTaskChecker




let checker = Checker(usersStorageClass: <#T##UsersStorageProtocol.Type#>,
                      postsStorageClass: <#T##PostsStorageProtocol.Type#>)
checker.run()

