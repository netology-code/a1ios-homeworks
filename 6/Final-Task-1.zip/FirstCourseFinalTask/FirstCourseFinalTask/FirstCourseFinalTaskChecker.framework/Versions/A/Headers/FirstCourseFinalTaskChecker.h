//
//  FirstCourseFinalTaskChecker.h
//  FirstCourseFinalTaskChecker
//
//  Copyright © 2017 E-Legion. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for FirstCourseFinalTaskChecker.
FOUNDATION_EXPORT double FirstCourseFinalTaskCheckerVersionNumber;

//! Project version string for FirstCourseFinalTaskChecker.
FOUNDATION_EXPORT const unsigned char FirstCourseFinalTaskCheckerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FirstCourseFinalTaskChecker/PublicHeader.h>


