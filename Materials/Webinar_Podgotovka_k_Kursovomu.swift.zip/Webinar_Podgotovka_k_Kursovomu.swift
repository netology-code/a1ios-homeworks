
/// Чтобы этот код работал, перенесите его либо в файл main (если это macOS)
/// либо в плейграунд
import Foundation

protocol Stylable {
    var steelWheels: Bool { get }
}

protocol Tintable {
    var tintWindows: Bool { get set }
}

protocol Sportable {
    func enableSrotMode()
}

// MARK: - Car
class Car: Tintable {
    
    var model: String
    let color: String
    let numberOfDoors: Int
    var tintWindows: Bool
    
    required init(model: String = "R8", myColor: String = "Red", numberOfDoors: Int, tintWindows: Bool) {
        self.model = model
        color = myColor
        self.numberOfDoors = numberOfDoors
        self.tintWindows = tintWindows
    }
    
}

// MARK: - Stylable
extension Car: Stylable {
    
    var steelWheels: Bool {
        return true
    }
}

extension Car: Sportable {
    func enableSrotMode() {
        print("Soprt mode has been enabled")
    }
}

let audi1 = Car(numberOfDoors: 2, tintWindows: true)
let audi2 = Car(myColor: "Black", numberOfDoors: 2, tintWindows: false)


enum Model {
    case smartphone
    case digitsPhone
    case discPhone
}

protocol PhoneInterface {
    var color: String { get set }
    var model: Model { get set }
    
    func makeCall()
}


class CallCenter {
    
    struct Smartphone: PhoneInterface {
        var color: String = "Red"
        var model: Model = .smartphone
        
        func makeCall() {
            print("Video call")
        }
    }
    
    struct DiscPhone: PhoneInterface {
        var color: String
        var model: Model = .discPhone
        
        func makeCall() {
            print("So long number calling call")
        }
    }
    
    struct DigitsPhone: PhoneInterface {
        var color: String
        var model: Model = .digitsPhone
        
        func makeCall() {
            print("Just a call")
        }
    }
    
    private var phones: [PhoneInterface]
    
    var smartphones = [PhoneInterface]()
    var discPhones = [PhoneInterface]()
    var didgitPhones = [PhoneInterface]()
    
    init(phones: [PhoneInterface]) {
        self.phones = phones
    }
    
    @discardableResult
    func makePhones() -> PhoneInterface? {
        for phone in phones {
            switch phone.model {
            case .digitsPhone:
                didgitPhones.append(phone)
            case .discPhone:
                discPhones.append(phone)
            case .smartphone:
                smartphones.append(phone)
            }
        }

        return nil
    }
    
}
typealias Smartphone = CallCenter.Smartphone
typealias DigitsPhone = CallCenter.DigitsPhone
typealias DiscPhone = CallCenter.DiscPhone

let callCenter = CallCenter(phones: [
    Smartphone(),
    Smartphone(),
    DigitsPhone(color: "Black"),
    DigitsPhone(color: "White"),
    DigitsPhone(color: "Orange"),
    DiscPhone(color: "Red"),
    DiscPhone(color: "Blue"),
    DiscPhone(color: "Green")
])

callCenter.makePhones()

//callCenter.didgitPhones.forEach { print($0.model, $0.color) }
//callCenter.discPhones.forEach { print($0.model, $0.color) }
//callCenter.smartphones.forEach { print($0.model, $0.color) }


// MARK: - Compact map
let anyValues: [Any?] = ["iPhone", "iPad", nil, 123, 20.331, Date(), nil, Int("123fdfs")]

//let intValues = devices.compactMap { $0 }
//intValues.forEach { print($0) }

let strValues = anyValues.compactMap { $0 as? String }
print(strValues)

// MARK: - Filter

let doubles = anyValues.filter { (value) -> Bool in
    if let _ = value as? Double {
        return true
    }
    return false
}

let names = ["Alex", "Bob", "Robert", "Ann", "Alexey"]

let aNames = names.filter { $0.hasPrefix("A") }
print(aNames)

let ids = [1234234, 123, 98540234, 123]

let id = ids.first(where: { $0 == 123 })!
print(id)

// MARK: - Map

struct Person {
    let name: String
}

let persons = names.map { Person(name: $0) }
let psersonsCount = names
    .map { Person(name: $0) }
    .filter { $0.name.hasPrefix("A") }
    .count

persons.forEach { print($0) }

//print(psersonsCount)

class Arithmetic {
    static func add<T: Summable>(x: T, y: T) -> T {
        return x + y
    }
}

protocol Summable {
    static func +(lhs: Self, hrs: Self) -> Self
}

extension Int: Summable {}
extension Double: Summable {}
extension String: Summable {}



print(Arithmetic.add(x: "Hello, ", y: "World!"))

