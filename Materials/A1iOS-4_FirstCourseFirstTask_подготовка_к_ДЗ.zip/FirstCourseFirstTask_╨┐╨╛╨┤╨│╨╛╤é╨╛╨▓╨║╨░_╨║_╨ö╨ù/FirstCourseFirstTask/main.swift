//
//  main.swift
//  FirstCourseFirstTask
//
//  Copyright © 2017 E-Legion. All rights reserved.
//

// Импортируем необходимые модули
import Foundation
import FirstCourseFirstTaskChecker


// Создаем экземпляр класса Checker для вызова проверок
let checker = Checker()


// Для получения первой части кодового слова вам нужно реализовать простую функцию. Она
// не принимает никаких параметров и просто возвращает строку "Hello, world!" (без кавычек).

func firstFunction() -> String {
    return "Hello, world!"
}

// Передача функции на проверку
//checker.checkFirstFunction(function: firstFunction)


// Для получения следующей части кодового слова вам нужно реализовать функцию, принимающую
// на вход два целых числа в виде строки и возвращающую результат их сложения в виде Int.
// Для конвертации строки в число воспользуйтесь инициализатором Int(String)! Восклицательный знак
// используется только потому, что мы знаем, что Checker не будет передавать некорректную строку и
// преобразование в Int всегда завершится успешно. В реальных проектах такой код использовать не
// следует. Более подробная информация об Optionals представлена в одноименной лекции.

func secondFunction(_ str1: String, _ str2: String) -> Int {
//    if let num1 = Int(str1), let num2 = Int(str2) {
//        return num1 + num2
//    }
    
    guard
        let num1 = Int(str1),
        let num2 = Int(str2)
    else { return 0 }
    
    return num1 + num2
}

// Передача второй функции на проверку
//checker.checkSecondFunction(function: secondFunction)


// Для получения последней части кодового слова вам нужно реализовать еще одну функцию.
// Чтобы узнать требования к ней нажмите левой кнопкой мыши на метод checkThirdFunction с
// зажатой клавишей cmd и переместитесь к его определению. Для преобразования данных в строку
// можно воспользоваться инициализатором String(describing: Any). Эта инициализация всегда
// заканчивается успешно. Поэтому не нужно использовать восклицательный знак.

func thirdFunction(_ currency: Checker.Currency, _ amount: Int) -> String {
    var result: String
    
    switch currency {
    case .eur:
        result = "€"
    case .usd:
        result = "$"
    case .rub:
        result = "₽"
    @unknown default:
        fatalError("Unknown currency: \(currency)")
    }
    
    if amount < 0 {
        let unsignedAmount = amount * -1
        return "(\(unsignedAmount)) \(result)"
    }
    
    return "\(amount) \(result)"
}

// Передача третьей функции на проверку
//checker.checkThirdFunction(function: thirdFunction)









// array
// dictionary
// cycles


// module
var age: Int = 65
let isEven: Bool = 10 % 2 == 0 ? true : false // остаток от деления на 2
let name = age >= 65 ? "Mr. Bob Shriber" : "Bob"

let array: [Int] = [1, 4, 6, 9]

//for number in array {
//    if number % 4 == 0 {
//        continue
//    }
//    print(number)
//}

//for i in 0..<array.count {
//    print(array[i])
//}

//array.forEach { number in
//    if number % 4 == 0 {
//        print(number)
//        return
//    }
//}


//let myName = "Alex"
//print(myName.hashValue)
//let yourName = "Alex"
//
//print(myName.hashValue == yourName.hashValue)

struct Student: Hashable {
    let name: String
    let age: Int
    let address: Home
}

struct Home: Hashable {
    let address: String
}

let alex = Student(name: "Bob", age: 31, address: Home(address: "123"))
let bob = Student(name: "Bob", age: 33, address: Home(address: "123"))

print(alex == bob)


struct Office {
    let address: String
}

var students: [String: String] = ["Alex": "Kolovatov", "Bob": "Shriber"]

students["Ilya"] = "Noskov"
students.updateValue("Fedorov", forKey: "Nikolay")
students["Ilya"] = nil
students.removeValue(forKey: "Nikolay")

//students.forEach {
//    print($0.value, $0.key)
//}

students.keys.forEach {
    print($0)
}

students.values.forEach {
    print($0)
}


if let _ = students["Alex"] {
    
}

let library: [String: [String]] = ["J": ["Jacbos", "Jill", "Jane"], "O": ["Onill", "Okey", "Obey"]]

//for element in library {
//    print(element.value)
//}

let arrayOfDicts = [
    1: ["J": ["Jacbos", "Jill", "Jane"], "K": ["Kile", "Klaus", "Kinder"]],
    2: ["O": ["Onill", "Okey", "Obey"]]
]

for element in arrayOfDicts {
    for dict in element.value {
        if dict.key == "O" {
            dict.value.forEach {
                if $0 == "Okey" {
                    print("WE have found it")
                }
            }
        }
    }
}

let someDict: [String: Any?] = ["A": 123, "B": 553425.55, "C": bob, "D": nil]
var result: Int = 877

for element in someDict {
    if let number = element.value as? Int {
        print(number + result)
    }
    if let doubleNum = element.value as? Double {
        print("its double \(doubleNum)")
    }
}

let nonOptional = someDict.values.compactMap { $0 }
let bValue = someDict.keys.first(where: { $0 == "B" })

let students2 = ["Klark", "Bob", "Alex", "Sara"]
let sortedStudents = students2.sorted(by: >)


let people: [[String: Any]] = [
    ["name": "Alex", "company": "Effective", "isStudent": true],
    ["name": "Bob", "company": "Apple", "isStudent": false],
]

struct Worker {
    let name: String
    var company: String
    var isStudent: Bool
}

var menArray: [Worker] = []

for element in people {
    if let name = element["name"] as? String,
        let company = element["company"] as? String,
        let isStudent = element["isStudent"] as? Bool {
       
        let man = Worker(name: name, company: company, isStudent: isStudent)
        
        menArray.append(man)
    }
}

let alexNew = menArray[0]
print(alexNew)

let alexName = alexNew.name

if alexNew.isStudent {
    print("Hello newbie")
}
