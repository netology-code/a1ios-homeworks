//
//  FirstCourseThirdTaskChecker.h
//  FirstCourseThirdTaskChecker
//
//  Copyright © 2017 E-Legion. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for FirstCourseThirdTaskChecker.
FOUNDATION_EXPORT double FirstCourseThirdTaskCheckerVersionNumber;

//! Project version string for FirstCourseThirdTaskChecker.
FOUNDATION_EXPORT const unsigned char FirstCourseThirdTaskCheckerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FirstCourseThirdTaskChecker/PublicHeader.h>


